```markdown
# O Espírito de Verdade

Site estático (HTML/CSS) apresentando "O Espírito de Verdade" — Orlindo Guimarães Cerqueira.

Arquivos:
- `index.html` — página principal.
- `styles.css` — estilos separados (minificados para simplicidade).
- `assets/` — pasta sugerida para imagens (não incluída).

Instruções rápidas
1. Estrutura sugerida:
   - index.html
   - styles.css
   - assets/
     - images/

2. Abrir localmente
   - Basta abrir `index.html` no navegador.
   - Para testes de CORS/requests locais, rode um servidor simples:
     - Python 3: `python -m http.server 8000`
     - Node (http-server): `npx http-server . -p 8000`

3. Integrar formulário (opções):
   - Formspree:
     1. Crie uma conta em https://formspree.io
     2. Copie o endpoint do formulário (ex.: https://formspree.io/f/your-id).
     3. No `index.html`, substitua o bloco de envio no `handleSubmit` por:
        fetch('https://formspree.io/f/your-id', { method: 'POST', body: new FormData(e.target) })
   - Netlify Forms:
     1. Adicione `data-netlify="true"` ao `<form>` e publique no Netlify.
     2. Exemplo:
        <form data-netlify="true" name="contact"> ... </form>
   - Google Forms:
     - Recomenda-se usar o formulário do Google embutido (iframe) ou configurar um endpoint do Google Apps Script para receber POST.

4. Deploy
   - GitHub Pages:
     - Crie um repositório, suba os arquivos e ative GitHub Pages na branch `main` (ou `gh-pages`).
   - Netlify / Vercel:
     - Conecte o repositório e publique (deploy automático).

Melhorias possíveis (próximos passos)
- Adicionar galeria de imagens com lightbox.
- Tornar o menu responsivo com botão "hamburger".
- Adicionar metadados Open Graph / Twitter Card.
- Internacionalização (i18n) — versão EN/ES/FR.
- Separar CSS ainda mais e minificar via build (ex.: PostCSS).

Licença
- Conteúdo: seu (fornecido por você).
- Código: livre para uso. Ajuste licenças conforme necessário.
```